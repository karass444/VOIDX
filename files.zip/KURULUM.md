# VOIDX v5.0 — Kurulum Talimatları

## 1. app.py Güncelle
```bash
cp ~/claude_output/app.py ~/VOIDX/app.py
```

## 2. Stripe Ayarları (app.py içinde)
```python
STRIPE_KEY = "sk_test_..."   # dashboard.stripe.com → API Keys
PRICE_ID   = "price_..."     # Stripe'da $5/ay subscription oluştur → Price ID
```

## 3. index.html'e Eklemeler

### A) <body> açıldıktan sonra ekle:
→ index_html_patch.html dosyasının üst kısmını kopyala

### B) </body> kapanmadan önce ekle:
→ index_html_patch.html dosyasının alt kısmını (limit modal) kopyala

### C) Mevcut <script> bloğunu değiştir:
→ index_js_patch.js içeriğini kopyala
   (doFetch fonksiyonunu ve tüm auth kodunu)

## 4. Sunucuyu Başlat
```bash
fuser -k 5000/tcp
cd ~/VOIDX && python3 app.py &
```

## 5. Test
- http://localhost:5000 → auth.html açılmalı
- Kayıt ol → index.html'e yönlenmeli
- 50 mesajdan sonra premium modal çıkmalı

## Önemli Notlar
- Stripe test modunda çalışır (sk_test_...)
- Gerçek ödeme için sk_live_... kullan
- Webhook için: stripe listen --forward-to localhost:5000/stripe/webhook
