<!-- index.html'e eklenecek JS değişiklikleri -->
<!-- Mevcut index.html'inizdeki <script> bloğunu aşağıdakiyle değiştirin -->

// ─── AUTH KONTROLÜ ───────────────────────────────────────────────────────────
const TOKEN = localStorage.getItem('voidx_token');
const USER  = JSON.parse(localStorage.getItem('voidx_user') || 'null');

if (!TOKEN || !USER) {
  window.location.href = 'auth.html';
}

// ─── KULLANICI BİLGİSİ & LIMIT ───────────────────────────────────────────────
async function loadUserInfo() {
  try {
    const res  = await fetch('http://localhost:5000/auth/me', {
      headers: { 'Authorization': 'Bearer ' + TOKEN }
    });
    const data = await res.json();

    // Kullanıcı emailini göster
    const emailEl = document.getElementById('user-email');
    if (emailEl) emailEl.textContent = data.email;

    // Plan badge
    const planEl = document.getElementById('user-plan');
    if (planEl) {
      planEl.textContent = data.plan === 'premium' ? '★ PREMIUM' : 'ÜCRETSİZ';
      planEl.style.color = data.plan === 'premium' ? '#c9a84c' : 'rgba(237,228,204,0.4)';
    }

    // Limit bar (sadece free kullanıcılara)
    if (data.plan === 'free') {
      const used  = data.usage_today || 0;
      const limit = data.limit || 50;
      const pct   = Math.min((used / limit) * 100, 100);

      const barEl = document.getElementById('usage-bar');
      const txtEl = document.getElementById('usage-text');
      if (barEl) barEl.style.width = pct + '%';
      if (txtEl) txtEl.textContent = `${used}/${limit} mesaj`;

      const wrapEl = document.getElementById('usage-wrap');
      if (wrapEl) wrapEl.style.display = 'block';
    }
  } catch(e) {}
}

// ─── ÇIKIŞ ───────────────────────────────────────────────────────────────────
function logout() {
  localStorage.removeItem('voidx_token');
  localStorage.removeItem('voidx_user');
  window.location.href = 'auth.html';
}

// ─── PREMIUM'A GEÇ ───────────────────────────────────────────────────────────
async function upgradeToPremium() {
  try {
    const res  = await fetch('http://localhost:5000/stripe/checkout', {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + TOKEN
      }
    });
    const data = await res.json();
    if (data.url) window.location.href = data.url;
    else alert('Stripe bağlantısı kurulamadı: ' + (data.error || ''));
  } catch(e) {
    alert('Sunucuya bağlanılamadı');
  }
}

// ─── CHAT (AUTH + LİMİT KONTROLÜ) ────────────────────────────────────────────
async function doFetch(msg, sid, pfx, cs, thid) {
  const th = document.createElement('div');
  th.className = 'msg ma';
  th.id = 'th' + thid;
  th.innerHTML = '<div class="pfx">' + pfx + '</div><span style="opacity:.3;font-size:10px;font-family:DM Mono,monospace">düşünüyor<span id="d' + thid + '">.</span></span>';
  cs.appendChild(th);
  cs.scrollTop = cs.scrollHeight;

  let di = 0;
  const iv = setInterval(function() {
    const d = document.getElementById('d' + thid);
    if (d) d.textContent = ['.', '..', '...'][di++ % 3];
  }, 400);

  try {
    const res = await fetch('http://localhost:5000/chat', {
      method: 'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + TOKEN
      },
      body: JSON.stringify({ message: msg, session_id: sid })
    });

    const data = await res.json();
    clearInterval(iv);
    const el = document.getElementById('th' + thid);
    if (el) el.remove();

    // Limit aşıldı mı?
    if (res.status === 429) {
      showLimitModal();
      return;
    }

    const reply = fmt(data.response || '—');
    addM(cs, 'ma', '<div class="pfx">' + pfx + '</div>' + reply);
    loadUserInfo(); // kullanım sayısını güncelle
    if (cs === sc1) saveHistory();

  } catch(e) {
    clearInterval(iv);
    const el = document.getElementById('th' + thid);
    if (el) el.remove();
    addM(cs, 'me', '// Sunucu çevrimdışı — terminalde: python3 app.py');
  }
}

// ─── LİMİT MODAL ─────────────────────────────────────────────────────────────
function showLimitModal() {
  const modal = document.getElementById('limit-modal');
  if (modal) modal.style.display = 'flex';
}
function closeLimitModal() {
  const modal = document.getElementById('limit-modal');
  if (modal) modal.style.display = 'none';
}

// Sayfa yüklendiğinde
loadUserInfo();
